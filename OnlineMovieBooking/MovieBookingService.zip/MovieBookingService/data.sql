create database bookMovie;

use bookMovie;

CREATE TABLE customer (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_role INT,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    phone_number VARCHAR(20),
    customer_statusid INT,
    verification_code INT,
    promotions_subscribed BIT,
    street VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    zipcode INT
);

CREATE TABLE customer_seq (
	next_val BIGINT DEFAULT 1
);

INSERT INTO customer_seq VALUES(1);

CREATE TABLE admin (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_role INT
);

CREATE TABLE admin_seq (
	next_val BIGINT DEFAULT 1
);

INSERT INTO admin_seq VALUES(1);

CREATE TABLE payment_cards (
    cardID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    card_type VARCHAR(255),
    card_number VARCHAR(255),
    expiry_date VARCHAR(255),
    security_number VARCHAr(255),
    name_on_card VARCHAR(255) ,
    street VARCHAR(255) NOT NULL,
    city VARCHAR(255) NOT NULL,
    state VARCHAR(255) NOT NULL,
    zipcode VARCHAR(255) NOT NULL,
    FOREIGN KEY (userID) REFERENCES customer(userID)  ON DELETE CASCADE
);

CREATE TABLE payment_cards_seq (
	next_val BIGINT DEFAULT 1
);

INSERT INTO payment_cards_seq VALUES(1);

CREATE TABLE movie(
	id int AUTO_INCREMENT NOT NULL Primary Key ,
	movie_title varchar(255),
	movie_cast varchar(2000),
	movie_category varchar(255),
	movie_director varchar(255),
	movie_producer varchar(255),
	release_date datetime ,
	synopsis varchar(2000) ,
	reviews varchar(2000) ,
	trailer_link varchar(255) ,
	movie_certification_code varchar(255) ,
	rating int ,
	movie_availability int ,
	poster_src varchar(255) , 
	banner_src varchar(255) ,
	language varchar(100)
);

CREATE TABLE movie_seq (
	next_val BIGINT DEFAULT 1
);

INSERT INTO movie_seq VALUES(1);


CREATE TABLE promotion (
    promo_Id INT AUTO_INCREMENT PRIMARY KEY,
    promo_code VARCHAR(255),
    promo_description VARCHAR(255),
    start_date datetime,
    end_date datetime,
    discount_applied DOUBLE
);

CREATE TABLE promotion_seq (
	next_val BIGINT DEFAULT 1
);

INSERT INTO promotion_seq VALUES(1);

CREATE TABLE show_schedule (
	show_Id INT AUTO_INCREMENT PRIMARY KEY,
	movie_Id INT,
	show_date datetime,
	show_time int,
	duration_minutes INT,
	FOREIGN KEY (movie_Id) REFERENCES movie(id)  ON DELETE CASCADE
);

CREATE TABLE show_schedule_seq (
	next_val BIGINT DEFAULT 1
);

insert into show_schedule_seq values(1);

CREATE TABLE show_reservations (
	seat_number VARCHAR(3),
	showID INT,
    PRIMARY KEY(seat_number, showID),
	FOREIGN KEY (showID) REFERENCES show_schedule(show_Id)  ON DELETE CASCADE
);

CREATE TABLE show_reservations_seq (
	next_val BIGINT DEFAULT 1
);

insert into show_reservations_seq values(1);

CREATE TABLE booking (
	booking_Id INT AUTO_INCREMENT PRIMARY KEY,
	customer_Id INT,
	payment_Id INT,
	movie_Id INT,
	show_Id INT,
	promo_code VARCHAR(15),
	total_price DOUBLE,
	booking_date DATETIME,
	booking_status INT,
    payment_status INT,
    FOREIGN KEY (customer_Id) REFERENCES customer(userID) ON DELETE CASCADE, 
    FOREIGN KEY (payment_Id) REFERENCES payment_cards(cardID) ON DELETE no action,
    FOREIGN KEY (movie_Id) REFERENCES movie(id) ON DELETE CASCADE,
    FOREIGN KEY (show_Id) REFERENCES show_schedule(show_Id) ON DELETE CASCADE
);

CREATE TABLE booking_seq (
	next_val BIGINT DEFAULT 1
);

insert into booking_seq values(1);

CREATE TABLE ticket (
	ticket_Id INT AUTO_INCREMENT PRIMARY KEY,
	booking_Id INT,
	seat_Id VARCHAR(3),
	ticket_type INT,
	ticket_price DOUBLE,
	FOREIGN KEY (booking_Id) REFERENCES booking(booking_Id) ON DELETE CASCADE
);

CREATE TABLE ticket_seq (
	next_val BIGINT DEFAULT 1
);

insert into ticket_seq values(1);

insert into admin values(1, 'sowndaryanookala3104@gmail.com', 'adminPassword', 0);

select * from payment_cards;
select * from customer;
select * from booking;
select * from show_reservations;
select * from admin;
delete from customer where userID  = 204;