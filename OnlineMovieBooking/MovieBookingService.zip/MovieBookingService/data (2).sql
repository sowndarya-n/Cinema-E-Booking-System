create database bookMovie;



CREATE TABLE customer (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_role INT,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    phone_number VARCHAR(20),
    customer_statusid INT,
    verification_code INT,
    promotions_subscribed BIT,
    street VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    zipcode INT
);


CREATE TABLE admin (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    userRole INT
);

CREATE TABLE payment_cards (
    cardID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    card_type VARCHAR(255),
    card_number VARCHAR(255),
    expiry_date VARCHAR(255),
    security_number VARCHAr(255),
    name_on_card VARCHAR(255) ,
    street VARCHAR(255) NOT NULL,
    city VARCHAR(255) NOT NULL,
    state VARCHAR(255) NOT NULL,
    zipcode VARCHAR(255) NOT NULL,
    FOREIGN KEY (userID) REFERENCES customer(userID)   
);

CREATE TABLE movie(
	id int AUTO_INCREMENT NOT NULL Primary Key ,
	movie_title varchar(255),
	movie_cast varchar(2000),
	movie_category varchar(255),
	movie_director varchar(255),
	movie_producer varchar(255),
	release_date datetime ,
	synopsis varchar(2000) ,
	reviews varchar(2000) ,
	trailer_link varchar(255) ,
	movie_certification_code varchar(255) ,
	rating int ,
	movie_availability int ,
	poster_src varchar(255) , 
	banner_src varchar(255) ,
	language varchar(100)
);

CREATE TABLE promotion (
    promoId INT AUTO_INCREMENT PRIMARY KEY,
    promoCode VARCHAR(255),
    promoDescription VARCHAR(255),
    startDate DATE,
    endDate DATE,
    discountApplied DOUBLE
);


INSERT INTO movie VALUES(1,"Barbie","Margot Robbie, Emma, Ryan Gosling, Will Ferrell","Comedy",'Greta Gerwig',"Tom Ackerly, David Herman, Margot Robbie", "2023-09-30 14:30:00", "2023-07-21", "A Comedy entertainer with children's fantasy character", "A good entertainer, Such a great movie", "https://www.youtube.com/embed/pBk4NYhWNMM?si=5UU5E32b1N4p8grq", "A", 5, 1, 0, 0, "../assets/img/barbie_now.jpg", "../assets/img/barbie_banner_now.jpg");
INSERT INTO movie VALUES(2,"Jawan","Sharukh Khan, Nayanthra, Deepika Padukone","Action",'Atlee',"Gauri Khan", "2023-09-30 14:30:00", "2023-09-07", "A high-octane action thriller where he is up against a dreadful monstrous outlaw who knows no fear and has caused extreme suffering to many", "A good action movie, Such a great movie", "https://www.youtube.com/embed/COv52Qyctws?si=UMLwKfcWJvuMvHty", "A", 5, 1, 0, 0, "../assets/img/jawan_now.jpg", "../assets/img/jawan_banner_now.jpg");
INSERT INTO movie VALUES(3,"The Nun II","Taissa Farmiga, Bonnie Aarons, Anna Popplewell, Storm Reid, Jonas Bloquet","Horror","Michael Chaves", "James Wan, Peter Safran", "2023-10-02 10:30:00", "2023-09-08", "Sister Irene returns to battle the demonic nun Valak, this time at a boarding school in France.", "The Nun 2 is a scarier and more engaging sequel to the first film. It is worth watching for fans of the franchise.", "https://www.youtube.com/embed/QF-oyCwaArU?si=sf0zp4zNfi-VDXlW", "A", 3, 1, 0, 0, "../assets/img/The_nun_II_poster.jpg", "../assets/img/The_nun_II_banner.jpg");
INSERT INTO movie VALUES(4,"Oppenheimer","Cillian Murphy,Emily Blunt,Matt Damon,Robert Downey Jr.,Florence Pugh,Josh Hartnett","Biography",'Christopher Nolan',"Emma Thomas, Charles Roven, Christopher Nolan", "2023-10-02 18:30:00", "2023-07-21", "Oppenheimer is a biopic about the life and career of J. Robert Oppenheimer, the theoretical physicist who led the Manhattan Project to develop the first nuclear weapons. The film explores the moral and philosophical implications of his work, and the legacy of the atomic bomb.", "Oppenheimer is a visually stunning and thought-provoking film with a career-best performance from Cillian Murphy. It is a must-see for anyone interested in history, science, or the human condition.", "https://www.youtube.com/embed/uYPbbksJxIg?si=ckknhiiDMb2QdqQw", "A", 5, 1, 0, 0, "../assets/img/oppenhiemer_poster.jpg", "../assets/img/oppenhiemer_banner.jpg");
INSERT INTO movie VALUES(5,"The Exorcist: Believer","Leslie Odom Jr., Ann Dowd,Jennifer Nettles, Norbert Leo Butz, Lidya Jewett, Olivia Marcum, Ellen Burstyn",'Horror','David Gordon Green','Jason Blum ,David C. Robinson,James G. Robinson', "2023-10-07 09:30:00", "2023-10-06", "A father seeks out Chris MacNeil, the only person who has ever survived an exorcism, to help his daughter, who is possessed by a demon.", "", "https://www.youtube.com/embed/rSGeC880CYw?si=PfpscV6aSSmKgjgJ", "A", 0, 0, 0, 1, "../assets/img/exorcist_poster.jpg", "../assets/img/exorcist_banner.jpg");
INSERT INTO movie VALUES(6,"Wish","	Ariana DeBose,Chris Pine,Alan Tudyk,Angelique Cabral,Victor Garber,Natasha Rothwell,Jennifer Kumiyama,Evan Peters,Harvey Guillén,Ramy Youssef,Niko Vargas,Della Saba,Jon Rudnitsky",'Animated Musical-Fantasy','Chris Buck, Fawn Veerasunthorn','Peter Del Vecho, Juan Pablo Reye', NULL , "2023-11-22", "A young girl in a magical kingdom makes a wish and an actual star falls from the sky to grant it.", "", "https://www.youtube.com/embed/oyRxxpD3yNw?si=JqPaNY7O6CmyrPG_", "A", 0, 0, 0, 1, "../assets/img/wish_poster.jpg", "../assets/img/wish_banner.jpg");


