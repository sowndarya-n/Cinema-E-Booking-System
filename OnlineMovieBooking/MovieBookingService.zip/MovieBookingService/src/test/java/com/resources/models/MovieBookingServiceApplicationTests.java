package com.resources.models;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
