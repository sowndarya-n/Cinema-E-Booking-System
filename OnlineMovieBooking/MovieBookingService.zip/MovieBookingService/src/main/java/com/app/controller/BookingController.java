package com.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.BookingDAO;
import com.app.resources.models.Booking;

@RestController
@CrossOrigin(origins="http://localhost:4200") 
public class BookingController {
	
	@Autowired
	private BookingDAO bookingDao;
	
	public int addBooking(Booking booking) {
		
		ResponseEntity.ok(bookingDao.save(booking));
		return booking.getBookingId();
		
	}
	
	public List<Booking> getBookingsByCustID(int id) {
		
		List<Booking> bookings = bookingDao.findByCustomerId(id);
		return bookings;
		
	}
	
    public Map<Integer, List<Booking>> getBookingsByBookingID(Booking booking) {
		
		Map<Integer, List<Booking>> result  = new HashMap<Integer, List<Booking>>();
		List<Booking> bookings = bookingDao.findByBookingId(booking.getBookingId());
		result.put(400, bookings);
		return result;
		
	}
    
    public Map<Integer, List<Booking>> getBookingsByMovieID(Booking booking) {
		
		Map<Integer, List<Booking>> result  = new HashMap<Integer, List<Booking>>();
		List<Booking> bookings = bookingDao.findByShowId(booking.getMovieId());
		result.put(400, bookings);
		return result;
		
	}

}
