package com.app.resources.enums;

public enum CustomerStatus {
	Active,
	InActive
}
