package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.resources.enums.TicketType;
import com.app.resources.models.Ticket;

@Repository
public interface TicketDAO extends JpaRepository<Ticket, Integer> {

	List<Ticket> findByBookingId(int bookingId);
	
	List<Ticket> findBySeatId(String seatId);
	
	List<Ticket> findByTicketType(TicketType ticketType);

}
