package com.app.controller.decorator;

public interface ITicketDecorator {
	
	double calculateTicketPrice();

}
