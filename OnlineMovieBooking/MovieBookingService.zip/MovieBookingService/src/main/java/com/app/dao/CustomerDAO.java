package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.resources.models.Customer;

@Repository
public interface CustomerDAO extends JpaRepository<Customer, Integer> { 
	
	    //Override the findAll method with different return type
		List<Customer> findAll();
		
		//Override the findByField method with different return type
		List<Customer> findByUserID(int userID);
		
		//Override the findByField method with different return type
		List<Customer> findByEmailAndPassword(String email, String password);
		
		List<Customer> findByEmail(String email);
		
		//Get the customers who subscribed for promotions
		List<Customer> findBypromotionsSubscribed(boolean promotionsSubscribed);



}
