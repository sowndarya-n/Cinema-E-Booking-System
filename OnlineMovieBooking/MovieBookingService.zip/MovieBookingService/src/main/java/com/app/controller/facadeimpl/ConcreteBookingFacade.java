package com.app.controller.facadeimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.controller.BookingController;
import com.app.controller.CustomerController;
import com.app.controller.MovieController;
import com.app.controller.PromotionController;
import com.app.controller.ShowController;
import com.app.controller.ShowReservationsController;
import com.app.controller.TicketController;
import com.app.controller.decorator.AdultTicketDecorator;
import com.app.controller.decorator.BaseTicketDecorator;
import com.app.controller.decorator.ChildTicketDecorator;
import com.app.controller.facade.IBookingFacade;
import com.app.resources.enums.BookingStatus;
import com.app.resources.enums.PaymentStatus;
import com.app.resources.enums.TicketType;
import com.app.resources.models.Booking;
import com.app.resources.models.BookingRequest;
import com.app.resources.models.Customer;
import com.app.resources.models.Movie;
import com.app.resources.models.PaymentCards;
import com.app.resources.models.Show;
import com.app.resources.models.ShowReservations;
import com.app.resources.models.Ticket;

@RestController
@CrossOrigin(origins="http://localhost:4200") 
public class ConcreteBookingFacade implements IBookingFacade{
	
	@Autowired
	private BookingController bookingController;
	@Autowired
	private ShowReservationsController reservationController;
	@Autowired
	private TicketController ticketController;
	@Autowired
	private PromotionController promotionController;
	@Autowired
	private CustomerController customerController;
	@Autowired
	private ShowController showController;
	@Autowired
	private MovieController movieController;
	
	@PostMapping("/addBooking")
	public BookingRequest addBooking(@RequestBody BookingRequest bookingRequest) {
		
		
		int id = bookingController.addBooking(bookingRequest.getBooking());
		double bookingPrice = 0;
		BaseTicketDecorator ticketDecor = new BaseTicketDecorator();
		for (Ticket ticket : bookingRequest.getTickets()) {
			
			reservationController.reserveSeat(
					        new ShowReservations(
							ticket.getSeatId(), 
							bookingRequest.getBooking().getShowId()));
			ticket.setBookingId(id);
			
			if(ticket.getTicketType().equals(TicketType.Adult)) {
				ticketDecor = new AdultTicketDecorator();
			}
			else {
				ticketDecor = new ChildTicketDecorator();
			}
			double price = ticketDecor.calculateTicketPrice();
			bookingPrice += price;
			ticket.setTicketPrice(price);
			ticketController.addTicket(ticket);
			
		}
		
		String code = bookingRequest.getBooking().getPromoCode();
		if(!code.isEmpty()) {
			
			double discount = promotionController.getDiscountByCode(code);
			double percentage = (bookingPrice * discount) / 100;
			bookingPrice -= percentage;
			
		}
		bookingPrice += ticketDecor.getSalesTax() + ticketDecor.getOnlineFee();
		
		bookingRequest.getBooking().setTotalPrice(bookingPrice);
		bookingRequest.getBooking().setBookingStatus(BookingStatus.Confirmed);
		bookingRequest.getBooking().setPaymentStatus(PaymentStatus.Success);
		bookingController.addBooking(bookingRequest.getBooking());
		
		Customer customer = new Customer();
		PaymentCards cards = new PaymentCards(); 
		Show show = new Show();
		Movie movie = new Movie();
		
		customer.setUserID(bookingRequest.getBooking().getCustomerId());
		cards.setCardID(bookingRequest.getBooking().getPaymentId());
		cards.setUserID(bookingRequest.getBooking().getCustomerId());
		customer = customerController.getCustomerById(customer).getBody().getCustomer();
		cards = customerController.getCardById(cards).getBody();
		show = showController.getShowByShowID(bookingRequest.getBooking().getShowId());
		movie = movieController.getMovieById(bookingRequest.getBooking().getMovieId());
		
		bookingRequest.setMovie(movie);
		bookingRequest.setShow(show);
		sendBookingConfirmationEmail(bookingRequest.getBooking(), bookingRequest.getTickets(), customer, cards, show, movie);
		return bookingRequest;
		
	}
	
	@PostMapping("/getCustomerBookings")
	public List<BookingRequest> getCustomerBookings(@RequestBody Map<String, Integer> request) {
		
		int customerID = request.get("customerID");
		List<Booking> bookings = bookingController.getBookingsByCustID(customerID);
		List<BookingRequest> bookingRequests = new ArrayList<BookingRequest>();
		
		for(Booking booking : bookings) {
			
			List<Ticket> ticketsList = ticketController.getTickets(booking.getBookingId());			
			BookingRequest bookingRequest = new BookingRequest();
			bookingRequest.setBooking(booking);
			bookingRequest.setTickets(ticketsList.toArray(new Ticket[0]));
			bookingRequest.setMovie(movieController.getMovieById(bookingRequest.getBooking().getMovieId()));
			bookingRequest.setShow(showController.getShowByShowID(bookingRequest.getBooking().getShowId()));
			bookingRequests.add(bookingRequest);
			
			
		}
		
	
		
		return bookingRequests;
		
	}

	public void sendBookingConfirmationEmail(Booking booking, Ticket[] tickets, Customer customer, PaymentCards cards, Show show, Movie movie) {
		
		String emailSubject = "Booking Confirmation";
		String emailBody = "Dear " + customer.getFirstName() + ",\n"
						 + "\nThank you for your order. Here are your booking confirmation details:\n"
						 + "Booking Details:\n"
						 + "Booking ID: " + booking.getBookingId()
						 + "\nBooking Date: " + booking.getBookingDate()
						 + "\nBooking Status: " + booking.getBookingStatus()
						 + "\n\nShow Details:\n"
						 + "Show Timings: " + show.getShowDate() + " " + show.getShowTime().getTime() + ":00\n"
						 + "Movie Title:  " + movie.getMovieTitle()
						 + "\nShow Duration: " + show.getDuration_minutes()
						 + "\n\nTicket Details: ";
		
		int i = 1;
		for (Ticket ticket : tickets) {
			emailBody += "\nTicket Number: " + i
					   + "\nSeat Number: " + ticket.getSeatId()
					   + "\nTicket Type: " + ticket.getTicketType()
					   + "\nTicket Price: " + ticket.getTicketPrice() + "\n";
			
		}
		
		if(!booking.getPromoCode().isEmpty()) {
			emailBody += "\nPromo applied: " + booking.getPromoCode() + "\n";
		}
		emailBody += "\nYour total order price is " + booking.getTotalPrice()
				   + " paid with card ending " + cards.getCardNumber().substring(cards.getCardNumber().length() - 4) + "\n";
		
		emailBody += "\nThank you for choosing our service. We look forward to serve you again \n"
				   + "\nRegards\n"
				   + "Team PopcornPicks";
		
		customerController.sendEmail(customer, emailBody, emailSubject);
		
	}

	@Override
	public Map<Integer, String> reserveSeat(ShowReservations request) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
