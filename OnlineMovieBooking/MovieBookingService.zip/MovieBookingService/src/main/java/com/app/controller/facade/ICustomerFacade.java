package com.app.controller.facade;

public interface ICustomerFacade {
	
	//CRUD Customer
	
	//CRUD Payment
	
	
}
