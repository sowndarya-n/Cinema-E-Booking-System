package com.app.resources.models;

public enum UserRole {
	Admin,
	Customer
}
