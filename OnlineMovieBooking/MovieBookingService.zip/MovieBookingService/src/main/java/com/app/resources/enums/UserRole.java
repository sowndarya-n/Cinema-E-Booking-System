package com.app.resources.enums;

public enum UserRole {
	Admin,
	Customer
}
