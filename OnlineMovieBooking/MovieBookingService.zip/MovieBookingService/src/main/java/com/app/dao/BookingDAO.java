package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.resources.models.Booking;

@Repository
public interface BookingDAO extends JpaRepository<Booking, Integer> {

	
	//Override the findAll method with different return type
	List<Booking> findAll();
		
	//Override the findByField method with different return type
	List<Booking> findByBookingId(int bookingId);
	
	List<Booking> findByCustomerId(int customerId);
	
	List<Booking> findByShowId(int showId);
	
	List<Booking> findByCustomerIdAndPromoCode(int customerId, String promoCode);


}
