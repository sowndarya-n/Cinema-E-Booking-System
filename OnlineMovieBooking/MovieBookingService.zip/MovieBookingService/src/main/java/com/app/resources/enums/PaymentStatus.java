package com.app.resources.enums;

public enum PaymentStatus {
	
	Success,
	Pending,
	Declined
	
}
