package com.app.controller.facade;

import java.util.Map;

import com.app.resources.models.Admin;
import com.app.resources.models.Movie;
import com.app.resources.models.Promotion;
import com.app.resources.models.Customer;


public interface IAdminFacade {

	Map<Integer, Movie> addMovie(Movie movie);
	void addAdmin(Admin admin);
	void addPromotion(Promotion promo);
	
	Map<Integer, Movie> updateMovie(Movie movie);
	void updateAdmin(Admin admin);
	void updateCustomer(Customer customer);

	
	boolean deleteMovie(Movie movie);
	void deleteAdmin(Admin admin);
	void deletePromotion(Promotion promo);
	void deleteCustomer(Customer customer);
	
	
}
