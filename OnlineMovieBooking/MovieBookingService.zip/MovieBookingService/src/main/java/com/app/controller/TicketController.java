package com.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.TicketDAO;
import com.app.resources.models.Ticket;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class TicketController {
	
	@Autowired
	private TicketDAO ticketDao;
	
	public Map<Integer, Ticket> addTicket(Ticket ticket) {
		
		Map<Integer, Ticket> result  = new HashMap<Integer, Ticket>();
		ResponseEntity.ok(ticketDao.save(ticket));
		result.put(400, ticket);
		return result;
		
	}
	
	public List<Ticket> getTickets(int bookingID) {
		return ticketDao.findByBookingId(bookingID);
	}
	
	
	

}
