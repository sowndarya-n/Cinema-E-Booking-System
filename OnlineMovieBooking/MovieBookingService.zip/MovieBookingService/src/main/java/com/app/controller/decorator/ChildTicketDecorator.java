package com.app.controller.decorator;

public class ChildTicketDecorator extends BaseTicketDecorator{

	protected double ticketPrice;
	
	public ChildTicketDecorator() {
		super();
		ticketPrice = 9;
	}
	
	@Override
	public double calculateTicketPrice() {
		
		return ticketPrice;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	
}
