package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.AddressDAO;
import com.app.resources.models.Address;

@RestController
@CrossOrigin(origins="http://localhost:4200") 
public class AddressController {
	
	@Autowired
	private AddressDAO addressDao;
	
	@PostMapping("/saveAddress")
	public ResponseEntity<Address> save(@RequestBody Address address) {
		
		if(checkAddressExists(address) == -1) {
			ResponseEntity.ok(addressDao.save(address));
		}

		address.setAddressID(addressDao.findByStreetAndCityAndStateAndZipcode(address.getStreet(), address.getCity(), address.getState(), address.getZipcode()).get(0).getAddressID());
		return new ResponseEntity<Address>(address, HttpStatus.OK); 
	}
	@PostMapping("/updateAddress")
	public ResponseEntity<Address> update(@RequestBody Address address) {
		if(checkAddressExists(address) == -1) {
			return new ResponseEntity<Address>(address, HttpStatus.NO_CONTENT); 
		}
		ResponseEntity.ok(addressDao.save(address));
		return new ResponseEntity<Address>(address, HttpStatus.OK); 
	}

	
	@GetMapping("/getAllAddresses")
	public List<Address> getAllAddresses() {
		 List<Address> list =  addressDao.findAll();
		 return list;
	}
	 
	
	 public int checkAddressExists (@RequestBody Address address ) {
		 
		 List<Address> addressList = addressDao.findByStreetAndCityAndStateAndZipcode(address.getStreet(),
				 																	  address.getCity(),
				 																	  address.getState(),
				 																	  address.getZipcode());	  
		  if (addressList.isEmpty()) { 
			  System.out.println("No address found");
			  return addressList.get(0).getAddressID();
		  }
		  
		  return -1;
	 }
	 
	 @PostMapping("/getAddress")
	 public ResponseEntity<Address> getAddress (@RequestBody Address address ) {
		  

		  List<Address> addressList = addressDao.findByAddressID(address.getAddressID());
		  if(addressList.isEmpty()) {
			  return new ResponseEntity<Address>(HttpStatus.NO_CONTENT);

		  }

		  Address addressResponse = addressList.get(0);
		  return new ResponseEntity<Address>(addressResponse,
		  HttpStatus.OK);
	  
	  }

	  @PostMapping("/deleteAddress")
	  public boolean deleteAddress(@RequestBody Address address) {
		  addressDao.delete(address);
		  return true;
	  }
	  
	  public Address saveorUpdate(Address address) {
		   int id = checkAddressExists(address);
			
			if(checkAddressExists(address) == -1) {
				addressDao.save(address);
				return address;
			}

			address.setAddressID(id);
			return address;		
	  }
	

}
