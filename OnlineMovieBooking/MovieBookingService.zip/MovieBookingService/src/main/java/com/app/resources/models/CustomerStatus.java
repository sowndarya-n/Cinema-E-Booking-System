package com.app.resources.models;

public enum CustomerStatus {
	Active,
	InActive
}
