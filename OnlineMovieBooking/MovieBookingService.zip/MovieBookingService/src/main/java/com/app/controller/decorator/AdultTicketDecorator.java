package com.app.controller.decorator;

public class AdultTicketDecorator extends BaseTicketDecorator{
	
    protected double ticketPrice;
	
	public AdultTicketDecorator() {
		super();
		ticketPrice = 11;
	}
	
	@Override
	public double calculateTicketPrice() {
		
		return ticketPrice;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}
	
}
