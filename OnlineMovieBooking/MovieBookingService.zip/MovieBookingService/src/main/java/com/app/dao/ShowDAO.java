package com.app.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.resources.enums.ShowTimes;
import com.app.resources.models.Show;

@Repository
public interface ShowDAO extends JpaRepository<Show, Integer> {

	List<Show> findByShowId(int showId);
	
	List<Show> findByMovieId(int movieId);
	
	List<Show> findByShowDateAndShowTime(Date showDate, ShowTimes showTime);
	
	List<Show> findByShowDate(Date showDate);
	
	List<Show> findByShowDateAndMovieId(Date showDate, int movieId);

}
