package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.PaymentCardsDAO;
import com.app.resources.models.PaymentCards;


@RestController
@CrossOrigin(origins="http://localhost:4200") 
public class PaymentCardController {
	
	@Autowired
	private PaymentCardsDAO paymentCardsDao;
	
//	@PostMapping("/addCard")
//	public ResponseEntity<PaymentCards> addCard(@RequestBody PaymentCards paymentCard) {
//		
//		if(!checkCardExists(paymentCard)) {
//			ResponseEntity.ok(paymentCardsDao.save(paymentCard));
//			return new ResponseEntity<PaymentCards>(paymentCard, HttpStatus.OK); 
//		}
//		 return new ResponseEntity<PaymentCards>(paymentCard, HttpStatus.BAD_REQUEST); 
//	}
	
	 @GetMapping("/getAllCards")
	 public List<PaymentCards> getAllCards() {
		 List<PaymentCards> list =  paymentCardsDao.findAll();
		 return list;
	 }
	 
	 public boolean checkCardExists (@RequestBody PaymentCards card) {
		 
		 int id = card.getCardID();
		  List<PaymentCards> cardList = paymentCardsDao.findByCardID(id);
		  
		  if (cardList.isEmpty()) { 
			  return false;
		  }
		  
		  return true;
	 
	 }
	 
	 
	 
	  public PaymentCards getCardByCardId(int id) {
		  
		  List<PaymentCards> cardList = paymentCardsDao.findByUserID(id);	  
		  return cardList.get(0);
	  
	  }
	 
	 
	 
	  
//	  @PostMapping("/updateCard")
//	  public boolean updateCard(@RequestBody PaymentCards card) {
//		  if(!checkCardExists(card)) {
//			  return false;
//		  }
//		  ResponseEntity.ok(paymentCardsDao.save(card));
//		  return true;
//	  }
	  
//	  @PostMapping("/deleteCard")
//	  public boolean deleteCard(@RequestBody PaymentCards card) {
//		  if(!checkCardExists(card)) {
//			  return false;
//		  }
//		  paymentCardsDao.delete(card);
//		  return true;
//	  }
	
}
