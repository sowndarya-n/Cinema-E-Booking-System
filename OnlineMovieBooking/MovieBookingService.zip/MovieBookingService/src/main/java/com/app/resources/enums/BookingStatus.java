package com.app.resources.enums;

public enum BookingStatus {
	
	Confirmed,
	Pending,
	Canceled

}
