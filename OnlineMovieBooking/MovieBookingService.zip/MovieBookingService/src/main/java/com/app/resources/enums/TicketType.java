package com.app.resources.enums;

public enum TicketType {
	
	Child,
	Adult

}
