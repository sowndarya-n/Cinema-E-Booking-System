package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.resources.models.Address;


@Repository
public interface AddressDAO extends JpaRepository<Address, Integer> { 
	List<Address> findByStreetAndCityAndStateAndZipcode(String street, 
			String city,
			String state,
			int zipcode);

	List<Address> findByAddressID(int addressID);

}
