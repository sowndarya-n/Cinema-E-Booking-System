package com.app.controller.facade;

import java.util.Map;

import com.app.resources.models.BookingRequest;
import com.app.resources.models.ShowReservations;

public interface IBookingFacade {
	
	// Reserve Seats
	Map<Integer, String> reserveSeat(ShowReservations request);

	
	// Create booking info
	BookingRequest addBooking(BookingRequest bookingRequest); 
	
	// Generate the tickets
	
	
}
