package com.app.controller.decorator;


public class BaseTicketDecorator implements ITicketDecorator{
	
	protected double salesTax;
	protected double onlineFee;
	
	public BaseTicketDecorator() {
		salesTax = 2.99;
		onlineFee = 2;
	}

	@Override
	public double calculateTicketPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getSalesTax() {
		return salesTax;
	}

	public double getOnlineFee() {
		return onlineFee;
	}

}
