package com.app.resources.enums;

public enum MovieAvailability {
	
	CurrentlyRunning,
	ComingSoon,
	Archived
	
}
